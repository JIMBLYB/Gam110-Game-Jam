INSTRUCTIONS

Drag the "Sample Textmesh" prefab onto your scene.

To resize font in Textmesh, use the "Character Size" attribute.
To resize font in UI, use "Scale".


STYLES

OL = Outlined
EX = Extruded
HS = Hard Shadow



LINKS

Need support?
https://twitter.com/pixelmush_

If you like this package, please help me out and leave a rating here:
http://u3d.as/v5t

Want more fonts?
http://u3d.as/w4v